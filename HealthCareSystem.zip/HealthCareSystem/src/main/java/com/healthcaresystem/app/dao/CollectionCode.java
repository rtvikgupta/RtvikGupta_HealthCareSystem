package com.healthcaresystem.app.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class CollectionCode {

	public ObjectInputStream file_read(File path) throws IOException {
		
		FileInputStream fis = null;
		fis = new FileInputStream(path);
		ObjectInputStream in = new ObjectInputStream(fis);
		
		return in;
	}
	
	public ObjectOutputStream file_write(File path) throws IOException {
		
		FileOutputStream fos = null;
		fos = new FileOutputStream(path);
		ObjectOutputStream out = new ObjectOutputStream(fos);
		
		return out;
	}
	
}
