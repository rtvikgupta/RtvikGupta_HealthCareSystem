package com.healthcaresystem.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.healthcaresystem.app.dao.CollectionCode;
import com.healthcaresystem.app.model.DiagnosticCenter;
import com.healthcaresystem.app.model.Test;
import com.healthcaresystem.app.view.MainClass;

public class RemoveTest {

	public void removeTest() {
		
		ViewCentersDetails view = new ViewCentersDetails();
		int count = view.displayCenter();
		
		if (count>0) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the Diagnostic Center Id: ");
			String centerId = sc.next();
			File path = new File("W:\\Health Care System\\HCS FINAL\\src\\main\\resources\\DiagnosticCenterDetails.txt");
			CollectionCode code = new CollectionCode();
			ArrayList<HashMap<String, DiagnosticCenter>> al = null;
			try {
				ObjectInputStream in = code.file_read(path);
				al = (ArrayList<HashMap<String, DiagnosticCenter>>) in.readObject();
				HashMap<String, DiagnosticCenter> hm = al.get(0);

				if (hm.containsKey(centerId)) {
					DiagnosticCenter dc = hm.get(centerId);

					System.out.println("Enter the Test Id to be removed: ");
					sc.nextLine();
					String testId = sc.nextLine();

					List<Test> test = dc.getListOfTests();
					int flag = 0;
					for (Test i : test) {
						if (i.getTestId().equals(testId)) {
							test.remove(i);
							flag = 1;
							break;
						}
					}

					if (flag == 0) {
						System.out.println("The test doesn't exist!!!");
						System.out.println("Please try again!!!");
						removeTest();
					} else {
						dc.setListOfTests(test);
						hm.put(centerId, dc);
						al.set(0, hm);
						in.close();
						
						ObjectOutputStream out = code.file_write(path);
						out.writeObject(al);
						out.close();
						System.out.println("Test details has been successfully removed!!!");
					}
				} else {
					System.out.println("Diagnostic Center with Id: " + centerId + " doesn't exist!!!");
					System.out.println("Please Try Again!!!");
					removeTest();
				}
			} catch(InputMismatchException ex) {
				System.out.println("Entered wrong input!!!");
				removeTest();
			}catch (IOException e) {
				System.out.println("IO EXCEPTION");
				MainClass.main(null);
			} catch (ClassNotFoundException e) {
				System.out.println("CLASS NOT FOUND EXCEPTION");
				MainClass.main(null);
			} catch (Exception e) {
				e.printStackTrace();
				MainClass.main(null);
			}
		}
		else
			System.out.println("SORRY, no diagnostic centers has been entered by the admin!!!");
	}
}
