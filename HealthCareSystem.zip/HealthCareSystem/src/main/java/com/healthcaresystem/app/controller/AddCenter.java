package com.healthcaresystem.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.healthcaresystem.app.dao.CollectionCode;
import com.healthcaresystem.app.dao.CollectionUtil;
import com.healthcaresystem.app.model.Appointment;
import com.healthcaresystem.app.model.DiagnosticCenter;
import com.healthcaresystem.app.model.Test;
import com.healthcaresystem.app.model.User;
import com.healthcaresystem.app.view.MainClass;

public class AddCenter {

	public void addCenter() {
		Scanner sc = new Scanner(System.in);
		
		String centerName="";
		String location = "";
		int openingYear=0;
		List<Test> listOfTests = null;
		
		System.out.println("Enter the Diagnostic Center Name: ");
		centerName = sc.nextLine();
		System.out.println("Enter 3 tests");
		listOfTests = new ArrayList<Test>();
		
		for (int i = 0; i < 3; i++) {
			System.out.println("Enter the Test Name: ");
			String testName = sc.nextLine();
			String testId = testName+"@123";
			Test test = new Test(testId, testName);
			listOfTests.add(test);
		}
		
		System.out.println("Enter the location: ");
		location = sc.nextLine();
		
		System.out.println("Enter the Opening Year: ");
		openingYear = sc.nextInt();
		
		List<Appointment> appointmentList = new ArrayList<Appointment>();
		String centerId ="";
		centerName = centerName.trim();
		if(centerName.contains(" "))
			centerId = centerName.substring(0,4)+"@123";
		else
			centerId = centerName+"@123";
		DiagnosticCenter dc = new DiagnosticCenter(centerName, centerId, listOfTests, appointmentList, location, openingYear);

		// To create diagnostic center details file empty database.
//		CollectionUtil util = new CollectionUtil();
//		util.dc_file_write(dc);
		
		File path = new File("W:\\Health Care System\\HCS FINAL\\src\\main\\resources\\DiagnosticCenterDetails.txt");
		CollectionCode code = new CollectionCode();
		ArrayList<HashMap<String, DiagnosticCenter>> al = null;
		try {
			ObjectInputStream in = code.file_read(path);
			al = (ArrayList<HashMap<String, DiagnosticCenter>>)in.readObject();
			HashMap<String, DiagnosticCenter> hm = al.get(0);
			hm.put(dc.getCenterId(),dc);
			al.set(0,hm);
			System.out.println("Diagnostic Center Id: "+dc.getCenterId());
			System.out.println("New Diagnostic Center added Successfully!!!");
			in.close();
			
			ObjectOutputStream out = code.file_write(path);
			out.writeObject(al);
			out.close();
		}  catch (IOException e) {
			System.out.println("IO EXCEPTION");
			MainClass.main(null);
		} catch (ClassNotFoundException e) {
			System.out.println("CLASS NOT FOUND EXCEPTION");
			MainClass.main(null);
		}
	}
}
