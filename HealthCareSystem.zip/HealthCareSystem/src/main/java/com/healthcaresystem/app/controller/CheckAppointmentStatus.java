package com.healthcaresystem.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.healthcaresystem.app.dao.CollectionCode;
import com.healthcaresystem.app.model.Appointment;
import com.healthcaresystem.app.model.DiagnosticCenter;
import com.healthcaresystem.app.view.MainClass;

public class CheckAppointmentStatus {
	
	public void status(String uid) {
		
		File path = new File("W:\\Health Care System\\HCS FINAL\\src\\main\\resources\\DiagnosticCenterDetails.txt");
		CollectionCode code = new CollectionCode();
		ArrayList<HashMap<String, DiagnosticCenter>> al = null;
		
		try {
			int i=0;
			ObjectInputStream in = code.file_read(path);
			al = (ArrayList<HashMap<String, DiagnosticCenter>>) in.readObject();
			HashMap<String, DiagnosticCenter> hm = al.get(0);
			int count=0;
			for (Map.Entry<String, DiagnosticCenter> m : hm.entrySet()) {
				DiagnosticCenter dc = m.getValue();
				List<Appointment> ap = dc.getAppointmentList();
				
				for (Appointment l : ap) {
					if(l.getUserId().equals(uid))
					{
						count++;
						System.out.println(++i + ". Appointment Id: "+l.getAppointmentId());
						System.out.println("\tStatus: "+l.getApproved());
						System.out.println("\tTest(s): "+l.getTest());
						System.out.println("\tLocation: "+dc.getCenterName()+","+dc.getLocation());
						System.out.println("\tDate and Time: "+l.getDatetime());
					}
				}
			}
			in.close();
			if(count==0)
				System.out.println("No appointment has been made!!!");
		}catch (IOException e) {
			System.out.println("IO EXCEPTION");
			MainClass.main(null);
		} catch (ClassNotFoundException e) {
			System.out.println("CLASS NOT FOUND EXCEPTION");
			MainClass.main(null);
		} 
		catch(Exception e) {
			e.printStackTrace();
			MainClass.main(null);
		}
		
	}
}
