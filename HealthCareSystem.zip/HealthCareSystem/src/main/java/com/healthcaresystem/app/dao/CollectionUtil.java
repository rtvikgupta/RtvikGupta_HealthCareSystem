package com.healthcaresystem.app.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.healthcaresystem.app.model.DiagnosticCenter;
import com.healthcaresystem.app.model.User;

public class CollectionUtil {
	
	// User details file
	public ObjectOutputStream user_file_write(User user) {
		
		user.setUserId("");
		ObjectOutputStream out=null;
		
		HashMap<String, User> hm = new HashMap<String, User>();
		ArrayList<HashMap<String, User>> al = new ArrayList<HashMap<String,User>>();
		al.add(0,hm);
		
		File path = new File("W:\\Health Care System\\HCS FINAL\\src\\main\\resources\\UserDetails.txt");
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(path);
			out = new ObjectOutputStream(fos);
			out.writeObject(al);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return out;
	}
	
	//Diagnostic center details file
	public ObjectOutputStream dc_file_write(DiagnosticCenter dc) {
		
		dc.setCenterId("");
		ObjectOutputStream out=null;
		
		HashMap<String, DiagnosticCenter> hm = new HashMap<String, DiagnosticCenter>();
		ArrayList<HashMap<String, DiagnosticCenter>> al = new ArrayList<HashMap<String,DiagnosticCenter>>();
		al.add(0,hm);
		
		File path = new File("W:\\Health Care System\\HCS FINAL\\src\\main\\resources\\DiagnosticCenterDetails.txt");
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(path);
			out = new ObjectOutputStream(fos);
			out.writeObject(al);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return out;
	}
}
