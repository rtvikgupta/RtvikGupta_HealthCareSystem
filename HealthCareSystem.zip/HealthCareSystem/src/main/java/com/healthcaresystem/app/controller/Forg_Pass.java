package com.healthcaresystem.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import com.healthcaresystem.app.dao.CollectionCode;
import com.healthcaresystem.app.model.User;
import com.healthcaresystem.app.view.MainClass;

public class Forg_Pass {

	public void forgot() {
		
		System.out.println("\n-------------------------------Reset Your Password-------------------------");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your User Id: ");
		String userId = sc.next();
		String pass = "";
		
		File path = new File("W:\\Health Care System\\HCS FINAL\\src\\main\\resources\\UserDetails.txt");
		CollectionCode code = new CollectionCode();
		ArrayList<HashMap<String, User>> al = null;
		
		aa:
		try {
			ObjectInputStream in = code.file_read(path);
			al = (ArrayList<HashMap<String, User>>)in.readObject();
			HashMap<String, User> hm = al.get(0);
			
			if(hm.containsKey(userId))
			{
				User user = hm.get(userId);
				System.out.println("Enter the new password: ");
				pass = sc.next();
				if(pass_validate(pass))
				{
					user.setUserPassword(pass);
					hm.put(user.getUserId(), user);
					al.set(0, hm);
					in.close();
					
					ObjectOutputStream out = code.file_write(path);
					out.writeObject(al);
					out.close();
					System.out.println("Password has been successfully resetted !!!");
					
				}
				else
				{
					System.out.println("Enter tha valid password. It should contains one number, one alphabet, one special character");
					break aa;
				}
			}
			else 
			{
				System.out.println("Enter the valid User Id!!!");
				break aa;
			}
			
		}catch (IOException e) {
			System.out.println("IO EXCEPTION");
			MainClass.main(null);
		} catch (ClassNotFoundException e) {
			System.out.println("CLASS NOT FOUND EXCEPTION");
			MainClass.main(null);
		}
		catch (Exception e) {
			e.printStackTrace();
			MainClass.main(null);
		}
	}
	
	public boolean pass_validate(String pass) {
		if(pass.length() >=8 && pass.length()<=14 ) {
			int num=0;
			int alpha=0;
			int spec=0;
			for(int i=0;i<pass.length();i++) {
				if((pass.charAt(i)>=65 && pass.charAt(i)<=90) || (pass.charAt(i)>=97 && pass.charAt(i)<=122))
				{
					alpha++;
				}
				else if(pass.charAt(i)>=48 && pass.charAt(i)<=57)
				{
					num++;
				}
				else
					spec++;
			}
			
			if(alpha>1 && num>0 && spec>0)
				return true;
		}
		return false;
	}
}
